CREATE TABLE student(
	id VARCHAR(10) PRIMARY KEY,
    name VARCHAR(10),
    tel INT
    );

CREATE TABLE subject(
	id VARCHAR(10) PRIMARY KEY,
    title VARCHAR(10),
    location INT
    );

CREATE TABLE Sugang(
	Sugangid VARCHAR(10) PRIMARY KEY,
    studentid VARCHAR(10),
	subjectid VARCHAR(10),
    CONSTRAINT FOREIGN KEY(회원id) REFERENCES student(id),
    CONSTRAINT FOREIGN KEY(과목id) REFERENCES subject(id)
);

INSERT INTO sutdent VALUES('park','park',011),('kim','kim',012)
INSERT INTO subject VALUES('s100','java',201),('s200','python',202)
INSERT INTO Sugang VALUES('c100','park','s100'),('c200','kim','s200')
