#쇼핑몰 상품 : 상품명(pk), 상품수량, 상품 분류, 상품 사이즈, 상품 색상,상품 가격
CREATE TABLE SHOP_ITEM(
	item_name VARCHAR(30) PRIMARY KEY UNIQUE,
   	item_amount INT DEFAULT 0,
	item_CF VARCHAR(20) NOT NULL,
    	item_size VARCHAR(30) NOT NULL DEFAULT '품절', 
    	item_color VARCHAR(20),
    	item_price INT NOT NULL
    );
    
#쇼핑몰 회원 : 회원 id, 회원 비밀번호, 회원이름, 주문상품, 주문개수,주문금액
CREATE TABLE shop_customer(
	customer_id VARCHAR(30) PRIMARY KEY,
    	customer_ps VARCHAR(15) NOT NULL,
    	customer_name VARCHAR(10) NOT NULL,
    	item_name VARCHAR(30),
    	item_amount INT DEFAULT 0,
   	item_price INT,
	FOREIGN KEY (item_name) REFERENCES shop_item(item_name)
    );

#쇼핑몰 관리자 : 상품명, 상품수량,회원이름, 주문상품, 주문개수, 주문금액
CREATE TABLE shop_manager(
    item_name VARCHAR(30) PRIMARY KEY,
    item_amount INT NOT NULL DEFAULT 0,
    customer_id VARCHAR(30) NOT NULL,
    customer_name VARCHAR(10) NOT NULL,
    customer_order VARCHAR(30),
    customer_order_amount INT,
    item_price INT,
	FOREIGN KEY (customer_id) REFERENCES shop_customer(customer_id),
    FOREIGN KEY (item_name) REFERENCES shop_item(item_name)
    );

