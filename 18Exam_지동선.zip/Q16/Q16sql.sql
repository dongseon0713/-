SELECT first_name||' '||last_name as Name,
        department_id,
        salary,
        RANK() OVER (ORDER BY salary DESC) as RANK,
        DENSE_RANK() OVER (ORDER BY salary DESC) AS DENSCRANK,
        ROW_NUMBER() OVER (ORDER BY salary DESC) AS ROWNUMBER
FROM employees
WHERE department_id = 50;