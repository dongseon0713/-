SELECT department_id,SUM(salary)
FROM employees
GROUP BY department_id
UNION
SELECT NULL,SUM(salary)
FROM employees;