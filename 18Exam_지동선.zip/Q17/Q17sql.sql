CREATE VIEW EMV_DEPT_VIEW 
AS
SELECT E.employee_id,E.first_name||' '||E.last_name as name,E.job_id,D.dname,D.loc
FROM employees E, dept D;